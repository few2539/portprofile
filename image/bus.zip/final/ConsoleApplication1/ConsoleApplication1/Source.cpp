#include <string>
#include <conio.h>

#include <cstdio>

#include <iostream>

#include <string.h>

#include <cstdlib>
#include <fstream>


using namespace std;
 int k = 0;

class b {
	char busno[5], driver[10], arrival[5], depart[5], Departtime[10], arrivaltime[10], seat[8][4][10];
public:
	void insertdetails();
	void reserve();
	void empty();
	void show();
	void ready();
	void position(int i);



}
bus[10];

void b::insertdetails()
{
	cout << "ENTER BUS no. ";
	cin >> bus[k].busno;
	cout << "\nENTER Driver name  ";
	cin >> bus[k].driver;
	cout << "\nENTER Depart: ";
	cin >> bus[k].depart;
	cout << "\nENTER Arrival: ";
	cin >> bus[k].arrival;
	cout << "\nENTER Depart time: ";
	cin >> bus[k].Departtime;
	cout << "\nENTER Arrival time: ";
	cin >> bus[k].arrivaltime;
	bus[k].empty();
	k++;

}
void dok(char y)

{

	for (int i = 80; i>0; i--)

		cout << y;

}
void b::reserve()

{

	int seat;

	char number[5];

top:

	cout << "Bus no: ";

	cin >> number;

	int n;

	for (n = 0; n <= k; n++)

	{

		if (strcmp(bus[n].busno, number) == 0)

			break;

	}

	while (n <= k)

	{

		cout << "\nSeat Number: ";

		cin >> seat;

		if (seat>32)

		{

			cout << "\n we have 32 seats for this bus.";

		}

		else

		{

			if (strcmp(bus[n].seat[seat / 4][(seat % 4) - 1], "Empty") == 0)

			{

				cout << "Enter Your name: ";

				cin >> bus[n].seat[seat / 4][(seat % 4) - 1];

				break;

			}

			else

				cout << " already reserved.\n";

		}

	}

	if (n>k)

	{

		cout << "Enter  bus no. again\n";

		goto top;

	}

}
void b::empty()
{

	for (int i = 0; i<8; i++)

	{

		for (int j = 0; j<4; j++)

		{

			strcpy_s(bus[k].seat[i][j], "Empty");

		}

	}

}
void b::show()
{

	int n;

	char number[5];

	cout << ".::Enter Which of bus number do you want to see about ticket::. " << endl;

	cin >> number;

	for (n = 0; n <= k; n++)

	{

		if (strcmp(bus[n].busno, number) == 0)


			break;

	}

	while (n <= k)

	{
		  cout << "*******************************************************************************";
           	cout << "\tBus no: \t" << bus[n].busno

			<< "\nDriver: \t" << bus[n].driver << "\tDeparture time:"<< bus[n].Departtime

			 << "\t\tArrival time: \t" << bus[n].arrivaltime

			<< "\nFrom: \t\t" << bus[n].depart << "\t\tTo: \t\t" <<

			bus[n].arrival << "\n";

			cout << "*******************************************************************************";
			cout << "\t_______________________________________________________________________________";

		bus[0].position(n);

		int a = 1;

		for (int i = 0; i<8; i++)

		{

			for (int j = 0; j<4; j++)

			{

				a++;

				if (strcmp(bus[n].seat[i][j], "Empty") != 0)

					cout << "\nThe seat no " << (a - 1) << " is reserved for " << bus[n].seat[i][j] << ".";

			}

		}

		break;

	}

	if (n>k)

		cout << "Enter correct bus no: ";

}
void b::ready()

{

	for (int n = 0; n < k; n++)
	{
		dok('*');
		cout << "bus number ::  \t" << bus[n].busno << endl;
		cout << "Driver :: \t" << bus[n].driver << endl;
		cout << "From ::\t" << bus[n].depart << endl;
		cout << "To ::\t" << bus[n].arrival << endl;
		cout << "Depart time" << bus[n].arrivaltime << endl;
		cout << "Arrival time" << bus[n].Departtime << endl;

		dok('_');
		dok('_');
	}
}

void b::position(int l)

{

	int s = 0; k= 0;

	for (int i = 0; i<8; i++)

	{

		cout << "\n";

		for (int j = 0; j<4; j++)

		{

			s++;

			if (strcmp(bus[l].seat[i][j], "Empty") == 0)

			{

				cout.width(5);

				cout.fill(' ');

				cout << s << ".";

				cout.width(10);

				cout.fill(' ');

				cout << bus[l].seat[i][j];

				k++;

			}

			else

			{

				cout.width(5);

				cout.fill(' ');

				cout << s << ".";

				cout.width(10);

				cout.fill(' ');

				cout << bus[l].seat[i][j];

			}

		}

	}

	cout << "\n\nThere are " << k << " seats empty in Bus No: " << bus[l].busno;

}

int main()

{

	
	int w;

	while (1)

	{
		
		cout << "\n\n\n\n\n";

		cout << "\t\t\t1.Install\n\t\t\t"

			<< "2.Reservation\n\t\t\t"

			<< "3.Show\n\t\t\t"

			<< "4.Buses Available. \n\t\t\t"

			<< "5.Exit";

		cout << "\n\t\t\tEnter your choice:-> ";

		cin >> w;

		switch (w)

		{

		case 1:  bus[k].insertdetails();

			break;

		case 2:  bus[k].reserve();

			break;

		case 3:  bus[0].show();

			break;

		case 4:  bus[k].ready();

			break;

		case 5: 	ofstream myfile("thank.txt", ios::out);
			myfile << "***********************bus station*******************\n";
			myfile << "***********************Thank a lot*******************\n";
			myfile << " ***********************Few, June*******************\n";
			exit(0);

		}

	}

	


	return 0;

}


